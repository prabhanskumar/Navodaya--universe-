"use client";

import { useRef, useState, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars, OrbitControls, Float } from "@react-three/drei";
import * as THREE from "three";

function InteractiveEarth({ autoRotate }: { autoRotate: boolean }) {
  const earthRef = useRef<THREE.Mesh>(null!);
  const cloudsRef = useRef<THREE.Mesh>(null!);
  const atmosphereRef = useRef<THREE.Mesh>(null!);
  const moonOrbitRef = useRef<THREE.Group>(null!);

  useFrame((_, delta) => {
    if (autoRotate) {
      earthRef.current.rotation.y += delta * 0.15;
      cloudsRef.current.rotation.y += delta * 0.18;
    }
    moonOrbitRef.current.rotation.y += delta * 0.3;
  });

  return (
    <group>
      {/* Atmosphere glow */}
      <mesh ref={atmosphereRef}>
        <sphereGeometry args={[2.6, 64, 64]} />
        <meshStandardMaterial color="#1a6aff" transparent opacity={0.15} side={THREE.BackSide} depthWrite={false} />
      </mesh>

      {/* Earth surface — realistic shading via multiple lights */}
      <mesh ref={earthRef} castShadow receiveShadow>
        <sphereGeometry args={[2.5, 96, 96]} />
        <meshStandardMaterial
          color="#1d4f8f"
          roughness={0.65}
          metalness={0.15}
          emissive="#0a1a3a"
          emissiveIntensity={0.25}
        />
      </mesh>

      {/* Cloud layer */}
      <mesh ref={cloudsRef}>
        <sphereGeometry args={[2.55, 96, 96]} />
        <meshStandardMaterial color="#dfeeff" transparent opacity={0.18} depthWrite={false} />
      </mesh>

      {/* Night-side city lights */}
      <pointLight color="#FFD700" intensity={0.3} distance={5} position={[-1.5, 0.8, 2.2]} />
      <pointLight color="#FFE55C" intensity={0.2} distance={4} position={[1.2, -0.5, 2.3]} />

      {/* Moon orbiting */}
      <group ref={moonOrbitRef}>
        <mesh position={[4.5, 0.6, 0]} castShadow>
          <sphereGeometry args={[0.6, 40, 40]} />
          <meshStandardMaterial color="#bbb8b0" roughness={0.9} emissive="#3a3830" emissiveIntensity={0.15} />
        </mesh>
      </group>
    </group>
  );
}

function Satellite({ radius, speed, tilt }: { radius: number; speed: number; tilt: number }) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.y += delta * speed;
  });
  return (
    <group ref={ref} rotation={[tilt, 0, 0]}>
      <mesh position={[radius, 0, 0]}>
        <boxGeometry args={[0.15, 0.15, 0.3]} />
        <meshStandardMaterial color="#dddddd" metalness={0.9} roughness={0.2} emissive="#00F0FF" emissiveIntensity={0.4} />
      </mesh>
      {/* Solar panels */}
      <mesh position={[radius, 0, 0]}>
        <boxGeometry args={[0.6, 0.02, 0.15]} />
        <meshStandardMaterial color="#1144aa" metalness={0.6} roughness={0.4} />
      </mesh>
    </group>
  );
}

export default function ExplorerEarth() {
  const [autoRotate, setAutoRotate] = useState(true);

  return (
    <div className="relative w-full h-full">
      <Canvas camera={{ position: [0, 0, 9], fov: 50 }} dpr={[1, 1.5]} shadows>
        <ambientLight intensity={0.15} />
        <directionalLight position={[6, 3, 5]} intensity={1.8} color="#ffffff" castShadow />
        <pointLight position={[-8, -4, -6]} intensity={0.3} color="#7B2FFF" />
        <Stars radius={80} depth={50} count={5000} factor={4} saturation={0.4} fade speed={0.4} />

        <Suspense fallback={null}>
          <Float speed={0.5} rotationIntensity={0} floatIntensity={0.2}>
            <InteractiveEarth autoRotate={autoRotate} />
          </Float>
          <Satellite radius={4} speed={0.5} tilt={0.3} />
          <Satellite radius={5} speed={-0.3} tilt={-0.5} />
        </Suspense>

        <OrbitControls
          enablePan={false}
          minDistance={4}
          maxDistance={16}
          autoRotate={false}
          onStart={() => setAutoRotate(false)}
          onEnd={() => setTimeout(() => setAutoRotate(true), 3000)}
        />
      </Canvas>
    </div>
  );
}
