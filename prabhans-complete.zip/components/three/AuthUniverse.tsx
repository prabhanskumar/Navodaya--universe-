"use client";

import { Suspense, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars, Float } from "@react-three/drei";
import * as THREE from "three";

function DriftingEarth() {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.y += delta * 0.06;
  });
  return (
    <mesh ref={ref} position={[5, -2, -6]}>
      <sphereGeometry args={[1.6, 48, 48]} />
      <meshStandardMaterial color="#1a4a8a" roughness={0.7} emissive="#0a1a3a" emissiveIntensity={0.3} />
    </mesh>
  );
}

function AmbientNebula() {
  return (
    <Float speed={0.3} rotationIntensity={0.05} floatIntensity={0.3}>
      <mesh position={[-4, 2, -10]}>
        <sphereGeometry args={[3, 16, 16]} />
        <meshBasicMaterial color="#5511aa" transparent opacity={0.04} />
      </mesh>
    </Float>
  );
}

export default function AuthUniverse() {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 0, background: "radial-gradient(ellipse at 50% 50%, #0a0025 0%, #020010 50%, #00000A 100%)" }}>
      <Canvas camera={{ position: [0, 0, 8], fov: 55 }} dpr={[1, 1.3]}>
        <ambientLight intensity={0.1} />
        <pointLight position={[8, 8, 5]} intensity={1.2} color="#4488ff" />
        <Stars radius={80} depth={50} count={4000} factor={4} saturation={0.4} fade speed={0.5} />
        <Suspense fallback={null}>
          <DriftingEarth />
          <AmbientNebula />
        </Suspense>
      </Canvas>
    </div>
  );
}
