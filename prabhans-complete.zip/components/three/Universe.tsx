"use client";

import { useRef, useMemo, Suspense } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Stars, Cloud, Sphere, Torus, useTexture, Float } from "@react-three/drei";
import * as THREE from "three";

/* ── Nebula Cloud ── */
function NebulaCloud({ position, color, opacity }: { position: [number, number, number]; color: string; opacity: number }) {
  return (
    <Cloud
      position={position}
      opacity={opacity}
      speed={0.1}
      width={8}
      depth={2}
      segments={12}
    >
      <meshStandardMaterial color={color} transparent opacity={opacity} depthWrite={false} />
    </Cloud>
  );
}

/* ── Earth ── */
function Earth() {
  const earthRef = useRef<THREE.Mesh>(null!);
  const cloudsRef = useRef<THREE.Mesh>(null!);
  const atmosphereRef = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    earthRef.current.rotation.y += delta * 0.08;
    cloudsRef.current.rotation.y += delta * 0.1;
    cloudsRef.current.rotation.x += delta * 0.02;
  });

  return (
    <group position={[4, -0.5, -8]}>
      {/* Atmosphere glow */}
      <mesh ref={atmosphereRef}>
        <sphereGeometry args={[2.1, 64, 64]} />
        <meshStandardMaterial
          color="#1a6aff"
          transparent
          opacity={0.12}
          side={THREE.BackSide}
          depthWrite={false}
        />
      </mesh>

      {/* Earth body */}
      <mesh ref={earthRef} castShadow>
        <sphereGeometry args={[2, 64, 64]} />
        <meshStandardMaterial
          color="#1a4a8a"
          roughness={0.7}
          metalness={0.1}
          emissive="#0a1a3a"
          emissiveIntensity={0.3}
        />
      </mesh>

      {/* Cloud layer */}
      <mesh ref={cloudsRef}>
        <sphereGeometry args={[2.04, 64, 64]} />
        <meshStandardMaterial
          color="#8bbfff"
          transparent
          opacity={0.15}
          depthWrite={false}
        />
      </mesh>

      {/* City lights (night side glow) */}
      <pointLight color="#FFD700" intensity={0.2} distance={4} position={[-1, 0.5, 1.8]} />

      {/* Moon orbit */}
      <Moon />
    </group>
  );
}

/* ── Moon ── */
function Moon() {
  const moonRef = useRef<THREE.Mesh>(null!);
  const orbitRef = useRef<THREE.Group>(null!);

  useFrame((_, delta) => {
    orbitRef.current.rotation.y += delta * 0.25;
  });

  return (
    <group ref={orbitRef}>
      <group position={[3.5, 0.5, 0]}>
        <mesh ref={moonRef}>
          <sphereGeometry args={[0.5, 32, 32]} />
          <meshStandardMaterial
            color="#bbb8b0"
            roughness={0.9}
            metalness={0.05}
            emissive="#444438"
            emissiveIntensity={0.1}
          />
        </mesh>
      </group>
    </group>
  );
}

/* ── Saturn ── */
function Saturn() {
  const saturnRef = useRef<THREE.Mesh>(null!);
  const ringRef = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    saturnRef.current.rotation.y += delta * 0.05;
    ringRef.current.rotation.z += delta * 0.02;
  });

  return (
    <group position={[-7, 2, -12]} rotation={[0.2, 0, 0]}>
      <mesh ref={saturnRef}>
        <sphereGeometry args={[1.5, 32, 32]} />
        <meshStandardMaterial
          color="#c8a04a"
          roughness={0.6}
          metalness={0.1}
          emissive="#3a2a0a"
          emissiveIntensity={0.2}
        />
      </mesh>
      <mesh ref={ringRef} rotation={[Math.PI / 2.5, 0, 0]}>
        <torusGeometry args={[2.5, 0.3, 4, 80]} />
        <meshStandardMaterial
          color="#d4a84a"
          transparent
          opacity={0.5}
          side={THREE.DoubleSide}
          roughness={0.8}
        />
      </mesh>
    </group>
  );
}

/* ── Shooting Meteors ── */
function ShootingMeteors() {
  const meteors = useMemo(() => {
    return Array.from({ length: 8 }, (_, i) => ({
      id: i,
      startPos: [
        (Math.random() - 0.5) * 40,
        Math.random() * 15 + 5,
        (Math.random() - 0.5) * 20 - 5,
      ] as [number, number, number],
      speed: 0.3 + Math.random() * 0.4,
      delay: Math.random() * 6,
      length: 0.8 + Math.random() * 1.5,
    }));
  }, []);

  return (
    <>
      {meteors.map((m) => (
        <MeteorTrail key={m.id} {...m} />
      ))}
    </>
  );
}

function MeteorTrail({
  startPos,
  speed,
  delay,
  length,
}: {
  startPos: [number, number, number];
  speed: number;
  delay: number;
  length: number;
}) {
  const ref = useRef<THREE.Mesh>(null!);
  const progress = useRef(-delay);

  useFrame((_, delta) => {
    progress.current += delta * speed;
    if (progress.current > 10) progress.current = -delay - 2;

    const t = progress.current;
    if (ref.current) {
      ref.current.position.set(
        startPos[0] - t * 4,
        startPos[1] - t * 3,
        startPos[2]
      );
      ref.current.visible = t > 0 && t < 4;
    }
  });

  return (
    <mesh ref={ref} rotation={[0, 0, Math.PI / 4]}>
      <cylinderGeometry args={[0.01, 0.005, length, 4]} />
      <meshStandardMaterial
        color="#ffffff"
        emissive="#88ccff"
        emissiveIntensity={2}
        transparent
        opacity={0.9}
      />
    </mesh>
  );
}

/* ── Floating Asteroids ── */
function Asteroids() {
  const asteroids = useMemo(() =>
    Array.from({ length: 15 }, (_, i) => ({
      id: i,
      position: [
        (Math.random() - 0.5) * 30,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 20 - 5,
      ] as [number, number, number],
      size: 0.05 + Math.random() * 0.15,
      rotSpeed: (Math.random() - 0.5) * 0.5,
    })),
  []);

  return (
    <>
      {asteroids.map((a) => (
        <RotatingAsteroid key={a.id} {...a} />
      ))}
    </>
  );
}

function RotatingAsteroid({ position, size, rotSpeed }: { position: [number,number,number]; size: number; rotSpeed: number; id: number }) {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.x += delta * rotSpeed;
    ref.current.rotation.y += delta * rotSpeed * 0.7;
  });
  return (
    <mesh ref={ref} position={position}>
      <dodecahedronGeometry args={[size, 0]} />
      <meshStandardMaterial color="#6a5a4a" roughness={0.95} metalness={0.1} />
    </mesh>
  );
}

/* ── Black Hole ── */
function BlackHole() {
  const ref = useRef<THREE.Mesh>(null!);
  const ringRef = useRef<THREE.Mesh>(null!);

  useFrame((_, delta) => {
    ringRef.current.rotation.z += delta * 0.3;
    ringRef.current.rotation.x += delta * 0.05;
  });

  return (
    <group position={[-12, 4, -20]}>
      {/* Core */}
      <mesh ref={ref}>
        <sphereGeometry args={[0.8, 32, 32]} />
        <meshBasicMaterial color="#000000" />
      </mesh>
      {/* Accretion disk */}
      <mesh ref={ringRef} rotation={[Math.PI / 6, 0, 0]}>
        <torusGeometry args={[2, 0.15, 8, 60]} />
        <meshStandardMaterial
          color="#ff6600"
          emissive="#ff3300"
          emissiveIntensity={3}
          transparent
          opacity={0.6}
        />
      </mesh>
      {/* Glow */}
      <pointLight color="#ff6600" intensity={2} distance={8} />
    </group>
  );
}

/* ── Camera Auto-movement ── */
function CameraRig() {
  const { camera } = useThree();
  const t = useRef(0);

  useFrame((_, delta) => {
    t.current += delta * 0.05;
    camera.position.x = Math.sin(t.current) * 0.8;
    camera.position.y = Math.cos(t.current * 0.7) * 0.3;
    camera.lookAt(0, 0, 0);
  });

  return null;
}

/* ── Space Dust Particles ── */
function SpaceDust() {
  const count = 300;
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 50;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 25;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 30 - 5;
    }
    return arr;
  }, []);

  const ref = useRef<THREE.Points>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.y += delta * 0.003;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#aaccff" size={0.015} transparent opacity={0.4} sizeAttenuation />
    </points>
  );
}

/* ── Main Universe Component ── */
export default function Universe() {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 0,
        background: "radial-gradient(ellipse at 50% 50%, #0a0025 0%, #020010 50%, #00000A 100%)",
      }}
    >
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        gl={{ antialias: true, alpha: false }}
        dpr={[1, 1.5]}
      >
        {/* Lighting */}
        <ambientLight intensity={0.08} />
        <pointLight position={[10, 10, 5]} intensity={1.5} color="#4488ff" />
        <pointLight position={[-10, -5, -10]} intensity={0.5} color="#7B2FFF" />
        <pointLight position={[0, 0, 0]} intensity={0.3} color="#00F0FF" />

        {/* Stars — three layers for depth */}
        <Stars radius={100} depth={60} count={6000} factor={4} saturation={0.5} fade speed={0.5} />
        <Stars radius={60} depth={40} count={3000} factor={3} saturation={1} fade speed={0.8} />
        <Stars radius={30} depth={20} count={1500} factor={2} saturation={1} fade speed={1.2} />

        <Suspense fallback={null}>
          {/* Celestial objects */}
          <Earth />
          <Saturn />
          <BlackHole />

          {/* Asteroids */}
          <Asteroids />

          {/* Space dust */}
          <SpaceDust />

          {/* Shooting meteors */}
          <ShootingMeteors />

          {/* Volumetric nebula */}
          <Float speed={0.4} rotationIntensity={0.1} floatIntensity={0.3}>
            <NebulaCloud position={[-5, 3, -15]} color="#3311aa" opacity={0.06} />
          </Float>
          <Float speed={0.3} rotationIntensity={0.05} floatIntensity={0.2}>
            <NebulaCloud position={[6, -2, -18]} color="#aa1166" opacity={0.05} />
          </Float>
          <Float speed={0.5} rotationIntensity={0.08} floatIntensity={0.4}>
            <NebulaCloud position={[0, 5, -20]} color="#1144aa" opacity={0.04} />
          </Float>
        </Suspense>

        {/* Camera drift */}
        <CameraRig />
      </Canvas>
    </div>
  );
}
