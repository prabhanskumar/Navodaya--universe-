"use client";

import { Suspense, useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Stars, Float } from "@react-three/drei";
import * as THREE from "three";

function Earth() {
  const earthRef = useRef<THREE.Mesh>(null!);
  const cloudsRef = useRef<THREE.Mesh>(null!);
  const orbitRef = useRef<THREE.Group>(null!);

  useFrame((_, delta) => {
    earthRef.current.rotation.y += delta * 0.08;
    cloudsRef.current.rotation.y += delta * 0.1;
    orbitRef.current.rotation.y += delta * 0.2;
  });

  return (
    <group position={[5, 1, -10]}>
      <mesh>
        <sphereGeometry args={[2.2, 48, 48]} />
        <meshStandardMaterial color="#1a6aff" transparent opacity={0.1} side={THREE.BackSide} depthWrite={false} />
      </mesh>
      <mesh ref={earthRef}>
        <sphereGeometry args={[2, 56, 56]} />
        <meshStandardMaterial color="#1a4a8a" roughness={0.7} emissive="#0a1a3a" emissiveIntensity={0.3} />
      </mesh>
      <mesh ref={cloudsRef}>
        <sphereGeometry args={[2.04, 56, 56]} />
        <meshStandardMaterial color="#8bbfff" transparent opacity={0.15} depthWrite={false} />
      </mesh>
      <pointLight color="#FFD700" intensity={0.2} distance={4} position={[-1, 0.5, 1.8]} />

      {/* Moon orbit */}
      <group ref={orbitRef}>
        <mesh position={[3.2, 0.4, 0]}>
          <sphereGeometry args={[0.45, 28, 28]} />
          <meshStandardMaterial color="#bbb8b0" roughness={0.9} emissive="#444438" emissiveIntensity={0.1} />
        </mesh>
      </group>

      {/* Satellites */}
      <Satellite radius={3.6} speed={0.4} yOffset={-0.5} />
      <Satellite radius={4.2} speed={-0.25} yOffset={0.8} />
    </group>
  );
}

function Satellite({ radius, speed, yOffset }: { radius: number; speed: number; yOffset: number }) {
  const ref = useRef<THREE.Group>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.y += delta * speed;
  });
  return (
    <group ref={ref}>
      <mesh position={[radius, yOffset, 0]}>
        <boxGeometry args={[0.12, 0.12, 0.25]} />
        <meshStandardMaterial color="#cccccc" metalness={0.8} roughness={0.3} emissive="#00F0FF" emissiveIntensity={0.3} />
      </mesh>
    </group>
  );
}

function NebulaGlow() {
  return (
    <Float speed={0.3} rotationIntensity={0.05} floatIntensity={0.3}>
      <mesh position={[-6, -2, -14]}>
        <sphereGeometry args={[3.5, 16, 16]} />
        <meshBasicMaterial color="#6611aa" transparent opacity={0.04} />
      </mesh>
    </Float>
  );
}

function SpaceDust() {
  const count = 200;
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 40;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 20;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 25 - 5;
    }
    return arr;
  }, []);
  const ref = useRef<THREE.Points>(null!);
  useFrame((_, delta) => {
    ref.current.rotation.y += delta * 0.003;
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial color="#aaccff" size={0.015} transparent opacity={0.35} sizeAttenuation />
    </points>
  );
}

export default function DashboardUniverse() {
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 0, background: "radial-gradient(ellipse at 50% 50%, #0a0025 0%, #020010 50%, #00000A 100%)" }}>
      <Canvas camera={{ position: [0, 0, 9], fov: 55 }} dpr={[1, 1.4]}>
        <ambientLight intensity={0.1} />
        <pointLight position={[8, 8, 5]} intensity={1.3} color="#4488ff" />
        <pointLight position={[-8, -4, -8]} intensity={0.4} color="#7B2FFF" />
        <Stars radius={90} depth={55} count={5000} factor={4} saturation={0.5} fade speed={0.5} />
        <Suspense fallback={null}>
          <Earth />
          <NebulaGlow />
          <SpaceDust />
        </Suspense>
      </Canvas>
    </div>
  );
}
