"use client";

import Link from "next/link";
import GlassCard from "@/components/ui/GlassCard";
import {
  FaRobot,
  FaBriefcase,
  FaGraduationCap,
  FaFolderOpen,
  FaDownload,
  FaChartLine,
  FaComments,
  FaGlobeAmericas,
  FaCog,
} from "react-icons/fa";

const CARDS = [
  { icon: FaRobot, title: "AI Assistant", desc: "Chat with your intelligent co-pilot.", href: "#", color: "cyan" as const },
  { icon: FaBriefcase, title: "Portfolio", desc: "Manage your showcased work.", href: "#", color: "purple" as const },
  { icon: FaGraduationCap, title: "Learning", desc: "Track courses and skill growth.", href: "#", color: "gold" as const },
  { icon: FaFolderOpen, title: "Projects", desc: "View and organize active builds.", href: "#", color: "cyan" as const },
  { icon: FaDownload, title: "Downloads", desc: "Access your exported files.", href: "#", color: "purple" as const },
  { icon: FaChartLine, title: "Analytics", desc: "Monitor performance metrics.", href: "#", color: "gold" as const },
  { icon: FaComments, title: "Chat", desc: "Message your team or contacts.", href: "#", color: "cyan" as const },
  { icon: FaGlobeAmericas, title: "Universe Explorer", desc: "Explore Earth in interactive 3D.", href: "/dashboard/universe", color: "purple" as const },
  { icon: FaCog, title: "Settings", desc: "Configure your account preferences.", href: "#", color: "gold" as const },
];

export default function DashboardCards() {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {CARDS.map((card, i) => (
        <Link key={card.title} href={card.href} className="cursor-none">
          <GlassCard
            tilt
            glowColor={card.color}
            className="p-6 flex flex-col gap-4 h-full transition-transform hover:-translate-y-1"
          >
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center animate-float"
              style={{
                background:
                  card.color === "cyan" ? "rgba(0,240,255,0.1)" : card.color === "purple" ? "rgba(123,47,255,0.1)" : "rgba(255,215,0,0.1)",
                animationDelay: `${i * 0.3}s`,
              }}
            >
              <card.icon size={20} color={card.color === "cyan" ? "#00F0FF" : card.color === "purple" ? "#A855F7" : "#FFD700"} />
            </div>
            <div>
              <h3 className="font-display font-semibold text-lg mb-1">{card.title}</h3>
              <p className="font-body text-sm" style={{ color: "rgba(240,248,255,0.55)" }}>
                {card.desc}
              </p>
            </div>
          </GlassCard>
        </Link>
      ))}
    </div>
  );
}
