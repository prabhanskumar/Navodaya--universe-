"use client";

import GlassCard from "@/components/ui/GlassCard";

const FACTS = [
  { label: "Diameter", value: "12,742 km" },
  { label: "Orbital Period", value: "365.25 days" },
  { label: "Moons", value: "1" },
  { label: "Rotation", value: "23h 56m" },
];

export default function ExplorerHUD() {
  return (
    <>
      {/* Top info panel */}
      <div className="absolute top-24 left-6 right-6 md:left-10 md:right-auto md:w-80 z-10">
        <GlassCard glowColor="cyan" className="p-6">
          <span className="font-mono text-xs uppercase tracking-[3px]" style={{ color: "#00F0FF" }}>
            Object Locked
          </span>
          <h2 className="font-display font-bold text-2xl mt-1 mb-4">Earth</h2>
          <div className="grid grid-cols-2 gap-3">
            {FACTS.map((fact) => (
              <div key={fact.label}>
                <p className="font-mono text-[10px] uppercase tracking-wider" style={{ color: "rgba(240,248,255,0.4)" }}>
                  {fact.label}
                </p>
                <p className="font-display text-sm font-semibold">{fact.value}</p>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Bottom controls hint */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
        <GlassCard className="px-6 py-3">
          <p className="font-mono text-xs" style={{ color: "rgba(240,248,255,0.5)" }}>
            🖱️ Drag to rotate &nbsp;•&nbsp; Scroll to zoom &nbsp;•&nbsp; Auto-rotation resumes after 3s
          </p>
        </GlassCard>
      </div>
    </>
  );
}
