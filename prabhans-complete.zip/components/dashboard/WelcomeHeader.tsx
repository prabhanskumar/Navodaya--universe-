"use client";

import { useEffect, useState } from "react";

export default function WelcomeHeader({ username }: { username: string }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div
      className="mb-10 transition-all duration-700"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(20px)",
      }}
    >
      <span className="font-mono text-xs uppercase tracking-[4px]" style={{ color: "rgba(0,240,255,0.6)" }}>
        Mission Control
      </span>
      <h1 className="font-display font-bold text-3xl md:text-4xl mt-2">
        Welcome Back,{" "}
        <span
          className="gradient-text-cyan inline-block"
          style={{
            animation: visible ? "pulseGlow 3s ease-in-out infinite" : "none",
          }}
        >
          {username}
        </span>
      </h1>
      <p className="font-body text-sm mt-2" style={{ color: "rgba(240,248,255,0.5)" }}>
        Your universe is online. Everything is operating nominally.
      </p>
    </div>
  );
}
