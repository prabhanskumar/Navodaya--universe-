"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { FaSearch, FaBell, FaCog, FaSignOutAlt } from "react-icons/fa";

export default function DashboardNav({ username, photoURL }: { username: string; photoURL?: string | null }) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/");
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-10 py-4"
      style={{
        background: "linear-gradient(180deg, rgba(0,0,10,0.92) 0%, rgba(0,0,10,0.6) 100%)",
        backdropFilter: "blur(14px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div
          className="w-8 h-8 rounded-full"
          style={{ background: "linear-gradient(135deg, #00F0FF, #7B2FFF)", boxShadow: "0 0 20px rgba(0,240,255,0.5)" }}
        />
        <span className="font-display font-bold text-lg tracking-widest hidden sm:inline" style={{ color: "#00F0FF" }}>
          PRABHANS
        </span>
      </div>

      {/* Search */}
      <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full flex-1 max-w-xs mx-6" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
        <FaSearch size={12} color="rgba(240,248,255,0.4)" />
        <input
          placeholder="Search the universe..."
          className="bg-transparent outline-none text-sm font-body w-full cursor-text"
          style={{ color: "#F0F8FF" }}
        />
      </div>

      {/* Right icons */}
      <div className="flex items-center gap-3 md:gap-5">
        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setNotifOpen((s) => !s)} className="relative cursor-none">
            <FaBell size={16} color="rgba(240,248,255,0.6)" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full" style={{ background: "#FFD700", boxShadow: "0 0 6px #FFD700" }} />
          </button>
          {notifOpen && (
            <div
              className="absolute right-0 top-8 w-64 glass-card p-4 text-sm font-body"
              style={{ color: "rgba(240,248,255,0.7)" }}
            >
              <p className="font-display text-xs uppercase tracking-widest mb-2" style={{ color: "#00F0FF" }}>
                Notifications
              </p>
              <p className="text-xs py-1">🚀 Your project deployment succeeded.</p>
              <p className="text-xs py-1">✨ New AI feature unlocked.</p>
              <p className="text-xs py-1">🛰️ Satellite sync complete.</p>
            </div>
          )}
        </div>

        {/* Settings */}
        <button className="cursor-none">
          <FaCog size={16} color="rgba(240,248,255,0.6)" />
        </button>

        {/* Avatar + menu */}
        <div className="relative">
          <button onClick={() => setMenuOpen((s) => !s)} className="flex items-center gap-2 cursor-none">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center font-display font-bold text-sm overflow-hidden"
              style={{
                background: photoURL ? "transparent" : "linear-gradient(135deg, #00F0FF, #7B2FFF)",
                boxShadow: "0 0 12px rgba(0,240,255,0.4)",
              }}
            >
              {photoURL ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={photoURL} alt={username} className="w-full h-full object-cover" loading="lazy" />
              ) : (
                username.charAt(0).toUpperCase()
              )}
            </div>
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-12 w-44 glass-card p-2">
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-sm font-body cursor-none hover:bg-white/5 transition-colors"
                style={{ color: "#FF8888" }}
              >
                <FaSignOutAlt size={13} /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
