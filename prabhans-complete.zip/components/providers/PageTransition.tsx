"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

export default function PageTransition() {
  const pathname = usePathname();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const t = setTimeout(() => setVisible(false), 500);
    return () => clearTimeout(t);
  }, [pathname]);

  return (
    <div
      className="fixed inset-0 z-[9997] pointer-events-none transition-opacity duration-500"
      style={{
        opacity: visible ? 1 : 0,
        background: "linear-gradient(135deg, #00000A 0%, #0a0025 100%)",
      }}
    />
  );
}
