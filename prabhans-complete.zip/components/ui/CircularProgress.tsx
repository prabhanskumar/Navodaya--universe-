"use client";

import { useEffect, useState } from "react";

interface CircularProgressProps {
  percentage: number;
  label: string;
  color?: string;
  delay?: number;
}

export default function CircularProgress({ percentage, label, color = "#00F0FF", delay = 0 }: CircularProgressProps) {
  const [animatedPct, setAnimatedPct] = useState(0);
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (animatedPct / 100) * circumference;

  useEffect(() => {
    const t = setTimeout(() => {
      const start = performance.now();
      const duration = 1400;
      const animate = (now: number) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setAnimatedPct(Math.round(eased * percentage));
        if (progress < 1) requestAnimationFrame(animate);
      };
      requestAnimationFrame(animate);
    }, delay);
    return () => clearTimeout(t);
  }, [percentage, delay]);

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 128 128">
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.08)"
            strokeWidth="8"
          />
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{
              transition: "stroke-dashoffset 0.3s ease",
              filter: `drop-shadow(0 0 6px ${color})`,
            }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display font-bold text-2xl">{animatedPct}%</span>
        </div>
      </div>
      <span className="font-body text-sm tracking-wide" style={{ color: "rgba(240,248,255,0.7)" }}>
        {label}
      </span>
    </div>
  );
}
