"use client";

import { useRef } from "react";

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  tilt?: boolean;
  glowColor?: "cyan" | "purple" | "gold";
}

const glowMap = {
  cyan: "rgba(0,240,255,0.35)",
  purple: "rgba(123,47,255,0.35)",
  gold: "rgba(255,215,0,0.35)",
};

export default function GlassCard({ children, className = "", tilt = false, glowColor = "cyan" }: GlassCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!tilt || !cardRef.current) return;
    const card = cardRef.current;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const rotateX = ((y - rect.height / 2) / rect.height) * -10;
    const rotateY = ((x - rect.width / 2) / rect.width) * 10;
    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
    card.style.setProperty("--glow-x", `${(x / rect.width) * 100}%`);
    card.style.setProperty("--glow-y", `${(y / rect.height) * 100}%`);
  };

  const handleLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = "perspective(800px) rotateX(0deg) rotateY(0deg) scale(1)";
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      className={`glass-card relative transition-transform duration-300 ease-out will-change-transform ${className}`}
      style={{
        backgroundImage: tilt
          ? `radial-gradient(circle at var(--glow-x, 50%) var(--glow-y, 50%), ${glowMap[glowColor]} 0%, transparent 60%), linear-gradient(135deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)`
          : undefined,
      }}
    >
      {children}
    </div>
  );
}
