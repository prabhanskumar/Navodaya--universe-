"use client";

import { useState, useEffect } from "react";

const TEXTS = [
  "AI Creator",
  "Future Developer",
  "Space Explorer",
  "Creative Designer",
  "Full Stack Engineer",
  "3D Web Artist",
  "Universe Builder",
];

export default function TypingText() {
  const [index, setIndex] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [pause, setPause] = useState(false);

  useEffect(() => {
    if (pause) {
      const t = setTimeout(() => setPause(false), 1500);
      return () => clearTimeout(t);
    }

    const current = TEXTS[index];
    const speed = deleting ? 50 : 80;

    const t = setTimeout(() => {
      if (!deleting) {
        setDisplayed(current.slice(0, displayed.length + 1));
        if (displayed.length + 1 === current.length) {
          setPause(true);
          setDeleting(true);
        }
      } else {
        setDisplayed(current.slice(0, displayed.length - 1));
        if (displayed.length === 0) {
          setDeleting(false);
          setIndex((i) => (i + 1) % TEXTS.length);
        }
      }
    }, speed);

    return () => clearTimeout(t);
  }, [displayed, deleting, index, pause]);

  return (
    <div className="flex items-center justify-center gap-1 h-10 md:h-14">
      <span
        className="font-display text-2xl md:text-4xl font-bold"
        style={{
          background: "linear-gradient(90deg, #00F0FF, #7B2FFF)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
        }}
      >
        {displayed}
      </span>
      <span
        className="w-0.5 h-8 md:h-12 bg-cyan-electric animate-pulse rounded-full"
        style={{ boxShadow: "0 0 8px #00F0FF" }}
      />
    </div>
  );
}
