"use client";

function getStrength(password: string): { score: number; label: string; color: string } {
  if (!password) return { score: 0, label: "", color: "rgba(255,255,255,0.1)" };

  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return { score: 1, label: "Weak", color: "#FF4D4D" };
  if (score <= 2) return { score: 2, label: "Fair", color: "#FFA500" };
  if (score <= 3) return { score: 3, label: "Good", color: "#FFD700" };
  if (score <= 4) return { score: 4, label: "Strong", color: "#00F0FF" };
  return { score: 5, label: "Excellent", color: "#00FF88" };
}

export default function PasswordStrength({ password }: { password: string }) {
  const { score, label, color } = getStrength(password);

  if (!password) return null;

  return (
    <div className="flex flex-col gap-1.5 mt-1">
      <div className="flex gap-1.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div
            key={i}
            className="h-1 flex-1 rounded-full transition-all duration-300"
            style={{
              background: i < score ? color : "rgba(255,255,255,0.1)",
              boxShadow: i < score ? `0 0 6px ${color}` : "none",
            }}
          />
        ))}
      </div>
      <span className="font-mono text-xs" style={{ color }}>
        {label}
      </span>
    </div>
  );
}
