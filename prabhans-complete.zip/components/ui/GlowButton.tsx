"use client";

import { useRef } from "react";
import Link from "next/link";

interface GlowButtonProps {
  label: string;
  href?: string;
  onClick?: () => void;
  variant?: "cyan" | "purple" | "gold" | "ghost";
  size?: "sm" | "md" | "lg";
  className?: string;
}

const variantStyles = {
  cyan: {
    bg: "linear-gradient(135deg, rgba(0,240,255,0.15), rgba(0,200,255,0.1))",
    border: "1px solid rgba(0,240,255,0.5)",
    shadow: "0 0 20px rgba(0,240,255,0.3)",
    hoverShadow: "0 0 40px rgba(0,240,255,0.6), 0 0 80px rgba(0,240,255,0.2)",
    text: "#00F0FF",
  },
  purple: {
    bg: "linear-gradient(135deg, rgba(123,47,255,0.2), rgba(168,85,247,0.1))",
    border: "1px solid rgba(123,47,255,0.5)",
    shadow: "0 0 20px rgba(123,47,255,0.3)",
    hoverShadow: "0 0 40px rgba(123,47,255,0.6), 0 0 80px rgba(123,47,255,0.2)",
    text: "#A855F7",
  },
  gold: {
    bg: "linear-gradient(135deg, rgba(255,215,0,0.15), rgba(255,165,0,0.1))",
    border: "1px solid rgba(255,215,0,0.5)",
    shadow: "0 0 20px rgba(255,215,0,0.3)",
    hoverShadow: "0 0 40px rgba(255,215,0,0.6), 0 0 80px rgba(255,215,0,0.2)",
    text: "#FFD700",
  },
  ghost: {
    bg: "linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02))",
    border: "1px solid rgba(255,255,255,0.15)",
    shadow: "none",
    hoverShadow: "0 0 20px rgba(255,255,255,0.1)",
    text: "#F0F8FF",
  },
};

const sizeStyles = {
  sm: "px-4 py-2 text-sm",
  md: "px-6 py-3 text-base",
  lg: "px-10 py-4 text-lg",
};

export default function GlowButton({
  label,
  href,
  onClick,
  variant = "cyan",
  size = "md",
  className = "",
}: GlowButtonProps) {
  const btnRef = useRef<HTMLButtonElement | HTMLAnchorElement>(null);
  const v = variantStyles[variant];

  const handleRipple = (e: React.MouseEvent) => {
    const btn = btnRef.current;
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement("span");
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    ripple.className = "ripple";
    ripple.style.cssText = `left:${x}px;top:${y}px;width:10px;height:10px;margin:-5px;`;
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
    onClick?.();
  };

  const sharedStyle: React.CSSProperties = {
    background: v.bg,
    border: v.border,
    boxShadow: v.shadow,
    color: v.text,
    transition: "all 0.3s ease",
  };

  const sharedClass = `btn-glow relative overflow-hidden rounded-full font-display font-semibold tracking-wider cursor-none select-none ${sizeStyles[size]} ${className}`;

  const hoverHandlers = {
    onMouseEnter: (e: React.MouseEvent<HTMLElement>) => {
      (e.currentTarget as HTMLElement).style.boxShadow = v.hoverShadow;
      (e.currentTarget as HTMLElement).style.transform = "translateY(-3px) scale(1.03)";
    },
    onMouseLeave: (e: React.MouseEvent<HTMLElement>) => {
      (e.currentTarget as HTMLElement).style.boxShadow = v.shadow;
      (e.currentTarget as HTMLElement).style.transform = "translateY(0) scale(1)";
    },
  };

  if (href) {
    return (
      <Link
        href={href}
        ref={btnRef as React.Ref<HTMLAnchorElement>}
        className={sharedClass}
        style={sharedStyle}
        onClick={handleRipple as unknown as React.MouseEventHandler<HTMLAnchorElement>}
        {...(hoverHandlers as unknown as React.AnchorHTMLAttributes<HTMLAnchorElement>)}
      >
        {label}
      </Link>
    );
  }

  return (
    <button
      ref={btnRef as React.Ref<HTMLButtonElement>}
      className={sharedClass}
      style={sharedStyle}
      onClick={handleRipple}
      {...hoverHandlers}
    >
      {label}
    </button>
  );
}
