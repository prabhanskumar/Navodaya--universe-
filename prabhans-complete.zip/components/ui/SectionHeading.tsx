interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  highlight?: string;
  description?: string;
  align?: "center" | "left";
}

export default function SectionHeading({
  eyebrow,
  title,
  highlight,
  description,
  align = "center",
}: SectionHeadingProps) {
  return (
    <div className={`flex flex-col gap-4 mb-12 md:mb-16 ${align === "center" ? "items-center text-center" : "items-start text-left"} max-w-3xl ${align === "center" ? "mx-auto" : ""}`}>
      <span
        className="px-4 py-1.5 rounded-full text-xs font-mono uppercase"
        style={{
          background: "rgba(0,240,255,0.08)",
          border: "1px solid rgba(0,240,255,0.25)",
          color: "#00F0FF",
          letterSpacing: "3px",
        }}
      >
        {eyebrow}
      </span>
      <h2 className="font-display font-bold text-3xl md:text-5xl leading-tight text-glow-white">
        {title}{" "}
        {highlight && (
          <span className="gradient-text-cyan">{highlight}</span>
        )}
      </h2>
      {description && (
        <p className="font-body text-base md:text-lg" style={{ color: "rgba(240,248,255,0.55)" }}>
          {description}
        </p>
      )}
    </div>
  );
}
