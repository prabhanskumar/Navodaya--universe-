"use client";

import { useReveal } from "@/lib/useReveal";
import SectionHeading from "@/components/ui/SectionHeading";
import CircularProgress from "@/components/ui/CircularProgress";

const SKILLS = [
  { label: "Programming", percentage: 95, color: "#00F0FF" },
  { label: "AI", percentage: 90, color: "#A855F7" },
  { label: "Design", percentage: 88, color: "#FFD700" },
  { label: "Creativity", percentage: 97, color: "#00C8FF" },
  { label: "Problem Solving", percentage: 93, color: "#D946EF" },
];

export default function SkillsSection() {
  const { ref, visible } = useReveal();

  return (
    <section id="skills" className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Capabilities"
          title="Skills That Power"
          highlight="The Mission"
          description="A balanced spectrum of technical depth and creative instinct, refined through real-world builds."
        />

        <div className="flex flex-wrap justify-center gap-10 md:gap-16">
          {SKILLS.map((skill, i) => (
            <CircularProgress
              key={skill.label}
              percentage={skill.percentage}
              label={skill.label}
              color={skill.color}
              delay={visible ? i * 150 : 999999}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
