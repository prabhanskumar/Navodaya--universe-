"use client";

import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import { FaArrowRight, FaGithub } from "react-icons/fa";

const PROJECTS = [
  {
    title: "Orion AI Assistant",
    desc: "A conversational AI interface with real-time context retrieval and a fully custom 3D avatar engine.",
    tags: ["Next.js", "OpenAI", "WebGL"],
    color: "cyan" as const,
  },
  {
    title: "Nebula Dashboard",
    desc: "An analytics command center with live data streams visualized through animated, glass-paneled widgets.",
    tags: ["React", "D3.js", "Firebase"],
    color: "purple" as const,
  },
  {
    title: "Stellar Commerce",
    desc: "A 3D-enhanced e-commerce experience where products rotate, glow, and respond to cursor gravity.",
    tags: ["Three.js", "Stripe", "Tailwind"],
    color: "gold" as const,
  },
  {
    title: "Cosmos Learning",
    desc: "An adaptive learning platform that reshapes its curriculum path using real-time performance signals.",
    tags: ["TypeScript", "Node.js", "AI"],
    color: "cyan" as const,
  },
];

export default function ProjectsSection() {
  const { ref, visible } = useReveal();

  return (
    <section id="projects" className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Selected Work"
          title="Projects Built"
          highlight="Beyond Limits"
          description="A curated showcase of platforms designed to feel alive — engineered with the same intention as PRABHANS itself."
        />

        <div className="grid md:grid-cols-2 gap-6">
          {PROJECTS.map((project) => (
            <GlassCard key={project.title} tilt glowColor={project.color} className="p-8 group cursor-none flex flex-col gap-4">
              <div className="flex items-start justify-between">
                <h3 className="font-display font-semibold text-2xl">{project.title}</h3>
                <FaGithub size={20} style={{ color: "rgba(240,248,255,0.4)" }} />
              </div>
              <p className="font-body text-sm leading-relaxed" style={{ color: "rgba(240,248,255,0.6)" }}>
                {project.desc}
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full text-xs font-mono"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      color: "rgba(240,248,255,0.6)",
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-2 font-mono text-sm transition-transform group-hover:translate-x-1" style={{ color: "#00F0FF" }}>
                View Project <FaArrowRight size={12} />
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
