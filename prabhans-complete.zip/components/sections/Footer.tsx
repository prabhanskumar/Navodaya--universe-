import { FaGithub, FaLinkedin, FaTwitter, FaEnvelope } from "react-icons/fa";

const LINKS = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Features", href: "#features" },
  { label: "Contact", href: "#contact" },
];

const SOCIALS = [
  { icon: FaGithub, href: "https://github.com" },
  { icon: FaLinkedin, href: "https://linkedin.com" },
  { icon: FaTwitter, href: "https://twitter.com" },
  { icon: FaEnvelope, href: "mailto:hello@prabhans.dev" },
];

export default function Footer() {
  return (
    <footer className="relative z-10 px-6 md:px-12 pt-20 pb-10 mt-10">
      {/* Top divider */}
      <div
        className="max-w-6xl mx-auto h-px mb-16"
        style={{ background: "linear-gradient(90deg, transparent, rgba(0,240,255,0.3), rgba(123,47,255,0.3), transparent)" }}
      />

      <div className="max-w-6xl mx-auto flex flex-col items-center gap-10">
        {/* Nav links */}
        <div className="flex flex-wrap justify-center gap-6 font-body text-sm" style={{ color: "rgba(240,248,255,0.6)" }}>
          {LINKS.map((link) => (
            <a key={link.label} href={link.href} className="hover:text-cyan-electric transition-colors cursor-none">
              {link.label}
            </a>
          ))}
        </div>

        {/* Socials */}
        <div className="flex gap-4">
          {SOCIALS.map((s, i) => (
            <a
              key={i}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full flex items-center justify-center cursor-none transition-all hover:-translate-y-1"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              <s.icon size={16} color="rgba(240,248,255,0.7)" />
            </a>
          ))}
        </div>

        {/* Signature */}
        <div className="flex flex-col items-center gap-2 mt-6">
          <span className="font-body text-xs uppercase tracking-[6px]" style={{ color: "rgba(240,248,255,0.4)" }}>
            Created &amp; Designed by
          </span>
          <h2
            className="font-display font-black select-none"
            style={{
              fontSize: "clamp(2.5rem, 8vw, 6rem)",
              background: "linear-gradient(135deg, #FFD700 0%, #FFE55C 25%, #00F0FF 60%, #7B2FFF 100%)",
              backgroundSize: "200% auto",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              animation: "shimmer 5s linear infinite",
              filter: "drop-shadow(0 0 40px rgba(255,215,0,0.3))",
              letterSpacing: "2px",
            }}
          >
            PRABHANS
          </h2>
        </div>

        {/* Copyright */}
        <p className="font-mono text-xs" style={{ color: "rgba(240,248,255,0.3)" }}>
          © {new Date().getFullYear()} PRABHANS — Beyond the Universe. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
