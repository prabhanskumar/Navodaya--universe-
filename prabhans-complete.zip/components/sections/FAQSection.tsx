"use client";

import { useState } from "react";
import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import { FaChevronDown } from "react-icons/fa";

const FAQS = [
  {
    q: "What technologies power this platform?",
    a: "PRABHANS is built with Next.js, TypeScript, Tailwind CSS, Three.js with React Three Fiber, Framer Motion, GSAP, and Firebase for authentication and data.",
  },
  {
    q: "Is the 3D universe optimized for mobile devices?",
    a: "Yes. The scene adapts resolution, particle counts, and rendering quality based on device capability so it stays smooth on phones and tablets.",
  },
  {
    q: "Can I customize the dashboard after logging in?",
    a: "Absolutely. The dashboard is modular — cards, layout, and theme accents can all be tailored to fit your workflow.",
  },
  {
    q: "How is my account data protected?",
    a: "Authentication runs through Firebase with industry-standard encryption, and all user data is stored securely in Firestore with strict access rules.",
  },
  {
    q: "Will more features be added to Universe Explorer?",
    a: "Yes — Universe Explorer is designed to expand over time with new celestial bodies, missions, and interactive layers.",
  },
];

export default function FAQSection() {
  const { ref, visible } = useReveal();
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-3xl mx-auto`}>
        <SectionHeading eyebrow="Questions" title="Frequently Asked" highlight="Questions" />

        <div className="flex flex-col gap-4">
          {FAQS.map((faq, i) => (
            <GlassCard key={faq.q} className="overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left cursor-none"
              >
                <span className="font-display font-medium text-base md:text-lg pr-4">{faq.q}</span>
                <FaChevronDown
                  size={14}
                  color="#00F0FF"
                  style={{
                    transform: open === i ? "rotate(180deg)" : "rotate(0deg)",
                    transition: "transform 0.3s ease",
                    flexShrink: 0,
                  }}
                />
              </button>
              <div
                style={{
                  maxHeight: open === i ? "200px" : "0px",
                  opacity: open === i ? 1 : 0,
                  transition: "max-height 0.4s ease, opacity 0.3s ease",
                  overflow: "hidden",
                }}
              >
                <p className="font-body text-sm px-6 pb-6 leading-relaxed" style={{ color: "rgba(240,248,255,0.6)" }}>
                  {faq.a}
                </p>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
