"use client";

import { useEffect, useRef, useState } from "react";
import TypingText from "@/components/ui/TypingText";
import GlowButton from "@/components/ui/GlowButton";

const NAV_BUTTONS = [
  { label: "Explore", href: "#about", variant: "cyan" as const },
  { label: "About", href: "#about", variant: "ghost" as const },
  { label: "Features", href: "#features", variant: "ghost" as const },
  { label: "Portfolio", href: "#projects", variant: "ghost" as const },
  { label: "Contact", href: "#contact", variant: "ghost" as const },
  { label: "Login →", href: "/login", variant: "gold" as const },
];

export default function HeroSection() {
  const logoRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Staggered entrance animation
    const logo = logoRef.current;
    const subtitle = subtitleRef.current;
    if (logo) {
      logo.style.opacity = "0";
      logo.style.transform = "translateY(30px) scale(0.95)";
      setTimeout(() => {
        logo.style.transition = "all 1.2s cubic-bezier(0.16, 1, 0.3, 1)";
        logo.style.opacity = "1";
        logo.style.transform = "translateY(0) scale(1)";
      }, 300);
    }
    if (subtitle) {
      subtitle.style.opacity = "0";
      subtitle.style.transform = "translateY(20px)";
      setTimeout(() => {
        subtitle.style.transition = "all 1s cubic-bezier(0.16, 1, 0.3, 1)";
        subtitle.style.opacity = "1";
        subtitle.style.transform = "translateY(0)";
      }, 700);
    }
  }, []);

  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center z-10 px-4"
      style={{ paddingTop: "80px" }}
    >
      {/* Top navigation bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 md:px-12 py-4"
        style={{
          background: "linear-gradient(180deg, rgba(0,0,10,0.9) 0%, transparent 100%)",
          backdropFilter: "blur(10px)",
        }}
      >
        <div className="flex items-center gap-2">
          {/* Logo mark */}
          <div
            className="w-8 h-8 rounded-full"
            style={{
              background: "linear-gradient(135deg, #00F0FF, #7B2FFF)",
              boxShadow: "0 0 20px rgba(0,240,255,0.5)",
            }}
          />
          <span
            className="font-display font-bold text-xl tracking-widest"
            style={{ color: "#00F0FF", textShadow: "0 0 10px rgba(0,240,255,0.5)" }}
          >
            PRABHANS
          </span>
        </div>

        <div className="hidden md:flex items-center gap-2">
          {NAV_BUTTONS.slice(1).map((btn) => (
            <GlowButton
              key={btn.label}
              label={btn.label}
              href={btn.href}
              variant={btn.variant}
              size="sm"
            />
          ))}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden flex flex-col gap-1.5 cursor-none z-50"
          aria-label="Toggle menu"
          aria-expanded={mobileMenuOpen}
          onClick={() => setMobileMenuOpen((s) => !s)}
        >
          <span
            className="w-6 h-0.5 bg-cyan-electric rounded-full transition-transform"
            style={{ transform: mobileMenuOpen ? "rotate(45deg) translateY(6px)" : "none" }}
          />
          <span
            className="w-4 h-0.5 bg-cyan-electric rounded-full transition-opacity"
            style={{ opacity: mobileMenuOpen ? 0 : 1 }}
          />
          <span
            className="w-6 h-0.5 bg-cyan-electric rounded-full transition-transform"
            style={{ transform: mobileMenuOpen ? "rotate(-45deg) translateY(-6px)" : "none" }}
          />
        </button>
      </nav>

      {/* Mobile menu drawer */}
      <div
        className="md:hidden fixed top-0 left-0 right-0 z-40 flex flex-col items-center justify-center gap-4 pt-24 pb-10 transition-all duration-400"
        style={{
          background: "rgba(0,0,10,0.97)",
          backdropFilter: "blur(20px)",
          maxHeight: mobileMenuOpen ? "500px" : "0px",
          opacity: mobileMenuOpen ? 1 : 0,
          overflow: "hidden",
        }}
        onClick={() => setMobileMenuOpen(false)}
      >
        {NAV_BUTTONS.slice(1).map((btn) => (
          <GlowButton
            key={btn.label}
            label={btn.label}
            href={btn.href}
            variant={btn.variant}
            size="md"
            className="w-48 text-center"
          />
        ))}
      </div>

      {/* Hero center content */}
      <div className="flex flex-col items-center text-center gap-6 max-w-5xl mx-auto">

        {/* Orbit badge */}
        <div
          className="px-4 py-2 rounded-full text-xs font-mono tracking-widest uppercase"
          style={{
            background: "rgba(0,240,255,0.08)",
            border: "1px solid rgba(0,240,255,0.25)",
            color: "#00F0FF",
            letterSpacing: "4px",
          }}
        >
          ◈ Beyond the Universe ◈
        </div>

        {/* Main Logo */}
        <h1
          ref={logoRef}
          className="font-display font-black leading-none select-none"
          style={{
            fontSize: "clamp(3.5rem, 12vw, 10rem)",
            background: "linear-gradient(135deg, #FFFFFF 0%, #00F0FF 40%, #7B2FFF 70%, #FFD700 100%)",
            backgroundSize: "200% auto",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            animation: "shimmer 6s linear infinite",
            filter: "drop-shadow(0 0 30px rgba(0,240,255,0.4))",
            letterSpacing: "-2px",
          }}
        >
          PRABHANS
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="font-body text-lg md:text-2xl tracking-widest uppercase"
          style={{
            color: "rgba(240,248,255,0.5)",
            letterSpacing: "8px",
          }}
        >
          Explore Beyond Imagination
        </p>

        {/* Typing text */}
        <TypingText />

        {/* Divider */}
        <div className="flex items-center gap-4 w-full max-w-xs">
          <div className="flex-1 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(0,240,255,0.4))" }} />
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-electric" style={{ boxShadow: "0 0 8px #00F0FF" }} />
          <div className="flex-1 h-px" style={{ background: "linear-gradient(270deg, transparent, rgba(0,240,255,0.4))" }} />
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-2">
          {NAV_BUTTONS.map((btn, i) => (
            <GlowButton
              key={btn.label}
              label={btn.label}
              href={btn.href}
              variant={btn.variant}
              size={i === 0 || i === NAV_BUTTONS.length - 1 ? "lg" : "md"}
            />
          ))}
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-xs font-mono tracking-widest" style={{ color: "rgba(0,240,255,0.4)" }}>
            SCROLL DOWN
          </span>
          <div className="relative w-5 h-8 rounded-full" style={{ border: "1px solid rgba(0,240,255,0.3)" }}>
            <div
              className="absolute left-1/2 -translate-x-1/2 top-1.5 w-1 h-2 rounded-full"
              style={{
                background: "#00F0FF",
                animation: "scrollBounce 2s ease-in-out infinite",
              }}
            />
          </div>
        </div>
      </div>

      {/* Radial gradient overlay for center glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(11,30,255,0.08) 0%, transparent 70%)",
          zIndex: -1,
        }}
      />

      <style jsx>{`
        @keyframes scrollBounce {
          0%, 100% { transform: translateX(-50%) translateY(0); opacity: 1; }
          50% { transform: translateX(-50%) translateY(10px); opacity: 0.3; }
        }
      `}</style>
    </section>
  );
}
