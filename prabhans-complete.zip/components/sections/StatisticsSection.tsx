"use client";

import { useReveal } from "@/lib/useReveal";
import { useCounter } from "@/lib/useCounter";

const STATS = [
  { value: 99.9, suffix: "%", label: "Performance" },
  { value: 100, suffix: "%", label: "Responsive" },
  { value: 1, suffix: "+", label: "Unlimited Creativity", display: "∞" },
  { value: 1, suffix: "", label: "Next Generation Experience", display: "NEXT-GEN" },
];

export default function StatisticsSection() {
  const { ref, visible } = useReveal();

  return (
    <section className="relative z-10 py-20 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-6xl mx-auto`}>
        <div
          className="glass-card grid grid-cols-2 md:grid-cols-4 gap-8 p-10 md:p-14"
          style={{
            background: "linear-gradient(135deg, rgba(0,240,255,0.04), rgba(123,47,255,0.04))",
          }}
        >
          {STATS.map((stat) => (
            <StatItem key={stat.label} stat={stat} trigger={visible} />
          ))}
        </div>
      </div>
    </section>
  );
}

function StatItem({
  stat,
  trigger,
}: {
  stat: { value: number; suffix: string; label: string; display?: string };
  trigger: boolean;
}) {
  const counted = useCounter(stat.value, trigger);

  return (
    <div className="flex flex-col items-center text-center gap-2">
      <span className="font-display font-black text-3xl md:text-5xl gradient-text-cyan">
        {stat.display ?? `${counted}${stat.suffix}`}
      </span>
      <span className="font-body text-xs md:text-sm uppercase tracking-widest" style={{ color: "rgba(240,248,255,0.5)" }}>
        {stat.label}
      </span>
    </div>
  );
}
