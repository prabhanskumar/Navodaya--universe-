"use client";

import { useState } from "react";
import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import GlowButton from "@/components/ui/GlowButton";
import { FaEnvelope, FaUser, FaPen } from "react-icons/fa";

export default function ContactSection() {
  const { ref, visible } = useReveal();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-2xl mx-auto`}>
        <SectionHeading
          eyebrow="Get In Touch"
          title="Let's Build Something"
          highlight="Extraordinary"
          description="Have a project in mind? Send a message and let's explore what's possible together."
        />

        <GlassCard glowColor="cyan" className="p-8 md:p-10">
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <FormField
              icon={FaUser}
              type="text"
              placeholder="Your Name"
              value={form.name}
              onChange={(v) => setForm({ ...form, name: v })}
            />
            <FormField
              icon={FaEnvelope}
              type="email"
              placeholder="Your Email"
              value={form.email}
              onChange={(v) => setForm({ ...form, email: v })}
            />
            <div className="relative">
              <FaPen className="absolute left-4 top-5" size={14} color="rgba(0,240,255,0.5)" />
              <textarea
                required
                rows={5}
                placeholder="Your Message"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full bg-transparent border rounded-xl pl-11 pr-4 py-4 font-body text-sm outline-none transition-all resize-none cursor-text"
                style={{
                  borderColor: "rgba(255,255,255,0.12)",
                  color: "#F0F8FF",
                }}
                onFocus={(e) => (e.target.style.borderColor = "rgba(0,240,255,0.5)")}
                onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
              />
            </div>

            <GlowButton label={submitted ? "Message Sent ✓" : "Send Message"} variant="cyan" size="lg" className="w-full" />
          </form>
        </GlassCard>
      </div>
    </section>
  );
}

function FormField({
  icon: Icon,
  type,
  placeholder,
  value,
  onChange,
}: {
  icon: React.ComponentType<{ size?: number; color?: string }>;
  type: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="relative">
      <span
        className="absolute"
        style={{ left: "16px", top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
      >
        <Icon size={14} color="rgba(0,240,255,0.5)" />
      </span>
      <input
        required
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-transparent border rounded-xl pl-11 pr-4 py-3.5 font-body text-sm outline-none transition-all cursor-text"
        style={{ borderColor: "rgba(255,255,255,0.12)", color: "#F0F8FF" }}
        onFocus={(e) => (e.target.style.borderColor = "rgba(0,240,255,0.5)")}
        onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
      />
    </div>
  );
}
