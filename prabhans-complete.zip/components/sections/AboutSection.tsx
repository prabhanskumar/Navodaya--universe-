"use client";

import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import { FaRocket, FaBrain, FaCode } from "react-icons/fa";

const TIMELINE = [
  {
    year: "2021",
    title: "First Line of Code",
    desc: "Started the journey into software development, exploring the fundamentals of logic and structure.",
  },
  {
    year: "2022",
    title: "Full-Stack Foundations",
    desc: "Built complete web applications end-to-end, mastering both frontend interfaces and backend systems.",
  },
  {
    year: "2023",
    title: "AI Integration",
    desc: "Began merging artificial intelligence into products, designing intelligent and adaptive experiences.",
  },
  {
    year: "2024",
    title: "3D & Immersive Web",
    desc: "Pushed into WebGL and real-time 3D graphics, crafting cinematic digital environments.",
  },
  {
    year: "2025+",
    title: "Beyond the Universe",
    desc: "Building PRABHANS — a platform that fuses design, AI, and space-grade engineering into one experience.",
  },
];

const PILLARS = [
  {
    icon: FaRocket,
    title: "Mission",
    text: "To craft digital experiences so polished and immersive they feel like products from the future, not the present.",
    color: "cyan" as const,
  },
  {
    icon: FaBrain,
    title: "Philosophy",
    text: "Every pixel, motion, and interaction should carry intention. Nothing exists on the page without a reason.",
    color: "purple" as const,
  },
  {
    icon: FaCode,
    title: "Craft",
    text: "Engineering excellence and visual artistry are not separate disciplines — they are the same discipline, practiced well.",
    color: "gold" as const,
  },
];

export default function AboutSection() {
  const { ref, visible } = useReveal();

  return (
    <section id="about" className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Who I Am"
          title="Engineering the"
          highlight="Future, by Hand"
          description="A builder operating at the intersection of design, artificial intelligence, and immersive 3D web — turning ambitious ideas into experiences that feel alive."
        />

        {/* Pillars */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {PILLARS.map((p) => (
            <GlassCard key={p.title} tilt glowColor={p.color} className="p-8 flex flex-col gap-4">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{
                  background:
                    p.color === "cyan"
                      ? "rgba(0,240,255,0.1)"
                      : p.color === "purple"
                      ? "rgba(123,47,255,0.1)"
                      : "rgba(255,215,0,0.1)",
                }}
              >
                <p.icon
                  size={22}
                  color={p.color === "cyan" ? "#00F0FF" : p.color === "purple" ? "#A855F7" : "#FFD700"}
                />
              </div>
              <h3 className="font-display font-semibold text-xl">{p.title}</h3>
              <p className="font-body text-sm leading-relaxed" style={{ color: "rgba(240,248,255,0.6)" }}>
                {p.text}
              </p>
            </GlassCard>
          ))}
        </div>

        {/* Timeline */}
        <div className="relative">
          <h3 className="font-display font-bold text-2xl md:text-3xl mb-10 text-center">
            The <span className="gradient-text-gold">Journey</span>
          </h3>

          <div className="relative">
            {/* Vertical line */}
            <div
              className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px md:-translate-x-1/2"
              style={{ background: "linear-gradient(180deg, transparent, rgba(0,240,255,0.4), rgba(123,47,255,0.4), transparent)" }}
            />

            <div className="flex flex-col gap-10">
              {TIMELINE.map((item, i) => (
                <TimelineItem key={item.year} item={item} index={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TimelineItem({
  item,
  index,
}: {
  item: { year: string; title: string; desc: string };
  index: number;
}) {
  const { ref, visible } = useReveal(0.3);
  const isEven = index % 2 === 0;

  return (
    <div
      ref={ref}
      className={`relative flex md:items-center gap-6 pl-12 md:pl-0 ${
        isEven ? "md:flex-row" : "md:flex-row-reverse"
      } section-reveal ${visible ? "visible" : ""}`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      {/* Dot */}
      <div
        className="absolute left-4 md:left-1/2 top-1 md:top-1/2 w-3 h-3 rounded-full -translate-x-1/2 md:-translate-y-1/2"
        style={{ background: "#00F0FF", boxShadow: "0 0 12px #00F0FF, 0 0 24px rgba(0,240,255,0.5)" }}
      />

      <div className={`flex-1 ${isEven ? "md:text-right md:pr-12" : "md:text-left md:pl-12"}`}>
        <GlassCard className="p-6 inline-block w-full md:w-auto md:min-w-[320px]">
          <span className="font-mono text-xs tracking-widest" style={{ color: "#FFD700" }}>
            {item.year}
          </span>
          <h4 className="font-display font-semibold text-lg mt-1 mb-2">{item.title}</h4>
          <p className="font-body text-sm" style={{ color: "rgba(240,248,255,0.55)" }}>
            {item.desc}
          </p>
        </GlassCard>
      </div>
      <div className="flex-1 hidden md:block" />
    </div>
  );
}
