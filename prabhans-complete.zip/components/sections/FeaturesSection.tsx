"use client";

import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import {
  FaBrain,
  FaBolt,
  FaShieldAlt,
  FaMobileAlt,
  FaHandPointer,
  FaCloud,
  FaGem,
  FaMagic,
} from "react-icons/fa";

const FEATURES = [
  { icon: FaBrain, title: "AI Powered", desc: "Intelligent systems woven into every interaction." },
  { icon: FaBolt, title: "Fast", desc: "Optimized for instant loads and fluid frame rates." },
  { icon: FaShieldAlt, title: "Secure", desc: "Authentication and data protected end-to-end." },
  { icon: FaMobileAlt, title: "Responsive", desc: "Flawless across desktop, tablet, and mobile." },
  { icon: FaHandPointer, title: "Interactive", desc: "Every element reacts with intention and feedback." },
  { icon: FaCloud, title: "Cloud Ready", desc: "Built on scalable, modern cloud infrastructure." },
  { icon: FaGem, title: "Premium UI", desc: "Crafted with luxury-grade visual polish." },
  { icon: FaMagic, title: "Advanced Animation", desc: "Cinematic motion design throughout." },
];

export default function FeaturesSection() {
  const { ref, visible } = useReveal();

  return (
    <section id="features" className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-6xl mx-auto`}>
        <SectionHeading
          eyebrow="Capabilities"
          title="Engineered for"
          highlight="Excellence"
          description="Every feature is built to a standard worthy of a next-generation digital product."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map((f, i) => (
            <GlassCard
              key={f.title}
              tilt
              glowColor={i % 3 === 0 ? "cyan" : i % 3 === 1 ? "purple" : "gold"}
              className="p-6 flex flex-col gap-3 animate-float"
            >
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ background: "rgba(0,240,255,0.08)" }}
              >
                <f.icon size={18} color="#00F0FF" />
              </div>
              <h3 className="font-display font-semibold text-base">{f.title}</h3>
              <p className="font-body text-xs leading-relaxed" style={{ color: "rgba(240,248,255,0.55)" }}>
                {f.desc}
              </p>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
