"use client";

import { useEffect, useState } from "react";
import { useReveal } from "@/lib/useReveal";
import GlassCard from "@/components/ui/GlassCard";
import SectionHeading from "@/components/ui/SectionHeading";
import { FaQuoteLeft, FaStar } from "react-icons/fa";

const TESTIMONIALS = [
  {
    name: "Elena Voss",
    role: "Product Director, Lumen Labs",
    quote: "Working with Prabhans felt like commissioning a studio, not hiring a freelancer. Every detail was deliberate.",
  },
  {
    name: "Marcus Chen",
    role: "Founder, Orbital Studio",
    quote: "The 3D experience he built didn't just look impressive — it actually performed flawlessly on every device we tested.",
  },
  {
    name: "Sarah Whitfield",
    role: "CTO, NovaStack",
    quote: "Rare to find someone equally strong in engineering rigor and visual taste. The result spoke for itself.",
  },
  {
    name: "Daniel Reyes",
    role: "Creative Lead, Halo Interactive",
    quote: "The animations felt cinematic without ever getting in the way of usability. That balance is hard to pull off.",
  },
];

export default function TestimonialsSection() {
  const { ref, visible } = useReveal();
  const [active, setActive] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActive((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative z-10 py-24 md:py-32 px-6 md:px-12">
      <div ref={ref} className={`section-reveal ${visible ? "visible" : ""} max-w-4xl mx-auto`}>
        <SectionHeading
          eyebrow="Trusted By"
          title="What People"
          highlight="Are Saying"
        />

        <div className="relative h-[280px] md:h-[240px]">
          {TESTIMONIALS.map((t, i) => (
            <div
              key={t.name}
              className="absolute inset-0 transition-all duration-700"
              style={{
                opacity: active === i ? 1 : 0,
                transform: active === i ? "translateX(0)" : "translateX(30px)",
                pointerEvents: active === i ? "auto" : "none",
              }}
            >
              <GlassCard className="p-8 md:p-10 h-full flex flex-col justify-between" glowColor="purple">
                <div>
                  <FaQuoteLeft size={28} color="#A855F7" style={{ opacity: 0.5 }} />
                  <p className="font-body text-lg md:text-xl mt-4 leading-relaxed" style={{ color: "rgba(240,248,255,0.85)" }}>
                    {t.quote}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-6">
                  <div>
                    <p className="font-display font-semibold">{t.name}</p>
                    <p className="font-body text-sm" style={{ color: "rgba(240,248,255,0.5)" }}>{t.role}</p>
                  </div>
                  <div className="flex gap-1">
                    {Array.from({ length: 5 }).map((_, idx) => (
                      <FaStar key={idx} size={14} color="#FFD700" />
                    ))}
                  </div>
                </div>
              </GlassCard>
            </div>
          ))}
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {TESTIMONIALS.map((t, i) => (
            <button
              key={t.name}
              onClick={() => setActive(i)}
              className="cursor-none transition-all rounded-full"
              style={{
                width: active === i ? "28px" : "8px",
                height: "8px",
                background: active === i ? "#00F0FF" : "rgba(255,255,255,0.2)",
                boxShadow: active === i ? "0 0 10px #00F0FF" : "none",
              }}
              aria-label={`Show testimonial ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
