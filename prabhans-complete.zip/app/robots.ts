import { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/dashboard", "/dashboard/universe"],
    },
    sitemap: "https://prabhans.dev/sitemap.xml",
  };
}
