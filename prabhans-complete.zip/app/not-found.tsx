import Link from "next/link";
import GlowButton from "@/components/ui/GlowButton";

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-6 px-6 text-center" style={{ background: "#00000A", color: "#F0F8FF" }}>
      <span className="font-mono text-xs uppercase tracking-[4px]" style={{ color: "rgba(0,240,255,0.6)" }}>
        Lost in Space
      </span>
      <h1
        className="font-display font-black"
        style={{
          fontSize: "clamp(4rem, 15vw, 9rem)",
          background: "linear-gradient(135deg, #00F0FF, #7B2FFF)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
        }}
      >
        404
      </h1>
      <p className="font-body text-base max-w-md" style={{ color: "rgba(240,248,255,0.5)" }}>
        This coordinate doesn&apos;t exist in our universe. Let&apos;s navigate you back.
      </p>
      <Link href="/">
        <GlowButton label="Return to PRABHANS" variant="cyan" size="lg" />
      </Link>
    </main>
  );
}
