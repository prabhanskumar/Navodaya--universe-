import dynamic from "next/dynamic";
import HeroSection from "@/components/sections/HeroSection";
import AboutSection from "@/components/sections/AboutSection";
import SkillsSection from "@/components/sections/SkillsSection";
import ProjectsSection from "@/components/sections/ProjectsSection";
import FeaturesSection from "@/components/sections/FeaturesSection";
import StatisticsSection from "@/components/sections/StatisticsSection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import FAQSection from "@/components/sections/FAQSection";
import ContactSection from "@/components/sections/ContactSection";
import Footer from "@/components/sections/Footer";
import MagneticCursor from "@/components/ui/MagneticCursor";

// 3D Universe is client-only & heavy — lazy load without SSR
const Universe = dynamic(() => import("@/components/three/Universe"), {
  ssr: false,
  loading: () => (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 0,
        background:
          "radial-gradient(ellipse at 50% 50%, #0a0025 0%, #020010 50%, #00000A 100%)",
      }}
    />
  ),
});

export default function Home() {
  return (
    <main className="relative w-full overflow-hidden">
      {/* Fixed 3D universe background */}
      <Universe />

      {/* Custom magnetic cursor (desktop) */}
      <MagneticCursor />

      {/* Hero / landing content */}
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ProjectsSection />
      <FeaturesSection />
      <StatisticsSection />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
