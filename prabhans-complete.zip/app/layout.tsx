import type { Metadata, Viewport } from "next";
import "./globals.css";
import SmoothScrollProvider from "@/components/providers/SmoothScrollProvider";
import PageTransition from "@/components/providers/PageTransition";
import { AuthProvider } from "@/lib/AuthContext";

export const metadata: Metadata = {
  metadataBase: new URL("https://prabhans.dev"),
  title: {
    default: "PRABHANS — Beyond the Universe",
    template: "%s | PRABHANS",
  },
  description: "Explore Beyond Imagination. A futuristic AI-powered portfolio platform.",
  keywords: ["PRABHANS", "AI", "portfolio", "futuristic", "developer", "space", "3D web", "Next.js portfolio"],
  authors: [{ name: "Prabhans" }],
  creator: "Prabhans",
  robots: { index: true, follow: true },
  openGraph: {
    title: "PRABHANS — Beyond the Universe",
    description: "Explore Beyond Imagination",
    type: "website",
    siteName: "PRABHANS",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "PRABHANS — Beyond the Universe",
    description: "Explore Beyond Imagination",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#00F0FF",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Exo+2:ital,wght@0,100..900;1,100..900&family=Share+Tech+Mono&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-space-black text-glow-white antialiased">
        <AuthProvider>
          <SmoothScrollProvider>
            <PageTransition />
            {children}
          </SmoothScrollProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
