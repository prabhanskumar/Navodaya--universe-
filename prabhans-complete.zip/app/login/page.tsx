"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, googleProvider, githubProvider } from "@/lib/firebase";
import { useAuth } from "@/lib/AuthContext";
import GlowButton from "@/components/ui/GlowButton";
import PasswordStrength from "@/components/ui/PasswordStrength";
import { FaEnvelope, FaLock, FaUser, FaGoogle, FaGithub, FaEye, FaEyeSlash } from "react-icons/fa";

const AuthUniverse = dynamic(() => import("@/components/three/AuthUniverse"), {
  ssr: false,
  loading: () => <div style={{ position: "fixed", inset: 0, background: "#00000A" }} />,
});

export default function LoginPage() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();

  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  // Redirect away if already logged in
  useEffect(() => {
    if (!authLoading && user) {
      router.push("/dashboard");
    }
  }, [user, authLoading, router]);

  const validate = () => {
    if (!email.includes("@")) return "Please enter a valid email address.";
    if (mode === "signup" && username.trim().length < 3) return "Username must be at least 3 characters.";
    if (password.length < 6) return "Password must be at least 6 characters.";
    return "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    try {
      if (mode === "signup") {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(cred.user, { displayName: username });
        await setDoc(doc(db, "users", cred.user.uid), {
          username,
          email,
          createdAt: serverTimestamp(),
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      setSuccess(true);
      setTimeout(() => router.push("/dashboard"), 800);
    } catch (err) {
      setError(formatFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleOAuth = async (provider: "google" | "github") => {
    setError("");
    setLoading(true);
    try {
      const cred = await signInWithPopup(auth, provider === "google" ? googleProvider : githubProvider);
      await setDoc(
        doc(db, "users", cred.user.uid),
        {
          username: cred.user.displayName ?? "Explorer",
          email: cred.user.email,
          createdAt: serverTimestamp(),
        },
        { merge: true }
      );
      setSuccess(true);
      setTimeout(() => router.push("/dashboard"), 800);
    } catch (err) {
      setError(formatFirebaseError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="relative w-full min-h-screen flex items-center justify-center px-4 py-12 overflow-hidden">
      <AuthUniverse />

      {/* Back to home */}
      <Link
        href="/"
        className="fixed top-6 left-6 z-20 font-display text-sm tracking-widest"
        style={{ color: "#00F0FF" }}
      >
        ← PRABHANS
      </Link>

      <div
        className="relative z-10 w-full max-w-md glass-card p-8 md:p-10"
        style={{ background: "linear-gradient(135deg, rgba(0,240,255,0.04), rgba(123,47,255,0.04))" }}
      >
        <div className="flex flex-col items-center gap-2 mb-8 text-center">
          <span className="font-mono text-xs uppercase tracking-[4px]" style={{ color: "#00F0FF" }}>
            {mode === "login" ? "Welcome Back" : "Join the Mission"}
          </span>
          <h1 className="font-display font-bold text-2xl md:text-3xl">
            {mode === "login" ? "Sign In to" : "Create Your"}{" "}
            <span className="gradient-text-cyan">{mode === "login" ? "PRABHANS" : "Account"}</span>
          </h1>
        </div>

        {/* Mode toggle */}
        <div className="flex gap-2 mb-6 p-1 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }}>
          {(["login", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => {
                setMode(m);
                setError("");
              }}
              className="flex-1 py-2 rounded-full font-display text-sm font-medium transition-all cursor-none"
              style={{
                background: mode === m ? "linear-gradient(135deg, rgba(0,240,255,0.2), rgba(123,47,255,0.15))" : "transparent",
                color: mode === m ? "#00F0FF" : "rgba(240,248,255,0.5)",
                boxShadow: mode === m ? "0 0 15px rgba(0,240,255,0.2)" : "none",
              }}
            >
              {m === "login" ? "Login" : "Sign Up"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {mode === "signup" && (
            <InputField icon={FaUser} type="text" placeholder="Username" value={username} onChange={setUsername} />
          )}
          <InputField icon={FaEnvelope} type="email" placeholder="Email" value={email} onChange={setEmail} />

          <div className="relative">
            <InputField
              icon={FaLock}
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={setPassword}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-4 top-1/2 -translate-y-1/2 cursor-none"
            >
              {showPassword ? (
                <FaEyeSlash size={14} color="rgba(240,248,255,0.4)" />
              ) : (
                <FaEye size={14} color="rgba(240,248,255,0.4)" />
              )}
            </button>
          </div>

          {mode === "signup" && <PasswordStrength password={password} />}

          {mode === "login" && (
            <div className="flex items-center justify-between text-xs font-body">
              <label className="flex items-center gap-2 cursor-none" style={{ color: "rgba(240,248,255,0.5)" }}>
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="cursor-none accent-cyan-500"
                />
                Remember Me
              </label>
              <button type="button" style={{ color: "#00F0FF" }} className="cursor-none">
                Forgot Password?
              </button>
            </div>
          )}

          {error && (
            <p className="font-body text-xs px-3 py-2 rounded-lg" style={{ background: "rgba(255,77,77,0.1)", color: "#FF8888", border: "1px solid rgba(255,77,77,0.3)" }}>
              {error}
            </p>
          )}

          <GlowButton
            label={loading ? "Please wait..." : success ? "Success ✓" : mode === "login" ? "Sign In" : "Create Account"}
            variant="cyan"
            size="lg"
            className="w-full mt-2"
          />
        </form>

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.1)" }} />
          <span className="font-mono text-xs" style={{ color: "rgba(240,248,255,0.3)" }}>OR</span>
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.1)" }} />
        </div>

        {/* OAuth buttons */}
        <div className="flex flex-col gap-3">
          <OAuthButton icon={FaGoogle} label="Continue with Google" onClick={() => handleOAuth("google")} />
          <OAuthButton icon={FaGithub} label="Continue with GitHub" onClick={() => handleOAuth("github")} />
        </div>

        <p className="text-center font-body text-sm mt-8" style={{ color: "rgba(240,248,255,0.5)" }}>
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => setMode(mode === "login" ? "signup" : "login")}
            style={{ color: "#FFD700" }}
            className="cursor-none font-medium"
          >
            {mode === "login" ? "Create Account" : "Sign In"}
          </button>
        </p>
      </div>
    </main>
  );
}

function InputField({
  icon: Icon,
  type,
  placeholder,
  value,
  onChange,
}: {
  icon: React.ComponentType<{ size?: number; color?: string }>;
  type: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="relative">
      <span className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
        <Icon size={14} color="rgba(0,240,255,0.5)" />
      </span>
      <input
        required
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-transparent border rounded-xl pl-11 pr-11 py-3.5 font-body text-sm outline-none transition-all cursor-text"
        style={{ borderColor: "rgba(255,255,255,0.12)", color: "#F0F8FF" }}
        onFocus={(e) => (e.target.style.borderColor = "rgba(0,240,255,0.5)")}
        onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
      />
    </div>
  );
}

function OAuthButton({
  icon: Icon,
  label,
  onClick,
}: {
  icon: React.ComponentType<{ size?: number }>;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center justify-center gap-3 w-full py-3 rounded-xl font-body text-sm font-medium transition-all cursor-none hover:-translate-y-0.5"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.12)",
        color: "#F0F8FF",
      }}
    >
      <Icon size={16} />
      {label}
    </button>
  );
}

function formatFirebaseError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? "";
  const map: Record<string, string> = {
    "auth/email-already-in-use": "An account with this email already exists.",
    "auth/invalid-email": "That email address looks invalid.",
    "auth/weak-password": "Password is too weak. Try a longer, more complex one.",
    "auth/user-not-found": "No account found with this email.",
    "auth/wrong-password": "Incorrect password. Please try again.",
    "auth/invalid-credential": "Invalid email or password.",
    "auth/popup-closed-by-user": "Sign-in popup was closed before completing.",
    "auth/network-request-failed": "Network error. Check your connection and try again.",
  };
  return map[code] ?? "Something went wrong. Please try again.";
}
