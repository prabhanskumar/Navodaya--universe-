"use client";

import { useEffect } from "react";
import Link from "next/link";
import GlowButton from "@/components/ui/GlowButton";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <html>
      <body style={{ background: "#00000A", color: "#F0F8FF" }}>
        <main className="min-h-screen flex flex-col items-center justify-center gap-6 px-6 text-center">
          <span className="font-mono text-xs uppercase tracking-[4px]" style={{ color: "#FF8888" }}>
            System Anomaly Detected
          </span>
          <h1 className="font-display font-bold text-3xl md:text-5xl">
            Something <span style={{ color: "#FF8888" }}>broke</span> in the universe.
          </h1>
          <p className="font-body text-sm max-w-md" style={{ color: "rgba(240,248,255,0.5)" }}>
            An unexpected error interrupted this transmission. You can try again, or return to safety.
          </p>
          <div className="flex gap-4 mt-2">
            <button
              onClick={reset}
              className="px-6 py-3 rounded-full font-display text-sm font-semibold"
              style={{ background: "rgba(0,240,255,0.1)", border: "1px solid rgba(0,240,255,0.4)", color: "#00F0FF" }}
            >
              Try Again
            </button>
            <Link href="/">
              <GlowButton label="Return Home" variant="gold" size="md" />
            </Link>
          </div>
        </main>
      </body>
    </html>
  );
}
