import { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "PRABHANS — Beyond the Universe",
    short_name: "PRABHANS",
    description: "Explore Beyond Imagination. A futuristic AI-powered portfolio platform.",
    start_url: "/",
    display: "standalone",
    background_color: "#00000A",
    theme_color: "#00F0FF",
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}
