"use client";

import dynamic from "next/dynamic";
import { useRequireAuth } from "@/lib/useRequireAuth";
import DashboardNav from "@/components/dashboard/DashboardNav";
import WelcomeHeader from "@/components/dashboard/WelcomeHeader";
import DashboardCards from "@/components/dashboard/DashboardCards";

const DashboardUniverse = dynamic(() => import("@/components/three/DashboardUniverse"), {
  ssr: false,
  loading: () => <div style={{ position: "fixed", inset: 0, background: "#00000A" }} />,
});

export default function DashboardPage() {
  const { user, loading } = useRequireAuth();

  if (loading || !user) {
    return (
      <main className="relative w-full min-h-screen flex items-center justify-center">
        <div style={{ position: "fixed", inset: 0, background: "#00000A" }} />
        <p className="font-display text-sm tracking-widest relative z-10" style={{ color: "#00F0FF" }}>
          Initializing Universe...
        </p>
      </main>
    );
  }

  const username = user.displayName ?? user.email?.split("@")[0] ?? "Explorer";

  return (
    <main className="relative w-full min-h-screen overflow-x-hidden">
      <DashboardUniverse />
      <DashboardNav username={username} photoURL={user.photoURL} />

      <div className="relative z-10 px-6 md:px-10 pt-28 pb-20 max-w-7xl mx-auto">
        <WelcomeHeader username={username} />
        <DashboardCards />
      </div>
    </main>
  );
}
