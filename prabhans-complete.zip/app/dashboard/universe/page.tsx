"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { useRequireAuth } from "@/lib/useRequireAuth";
import { FaArrowLeft } from "react-icons/fa";

const ExplorerEarth = dynamic(() => import("@/components/three/ExplorerEarth"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center">
      <p className="font-display text-sm tracking-widest" style={{ color: "#00F0FF" }}>
        Loading Universe...
      </p>
    </div>
  ),
});

const ExplorerHUD = dynamic(() => import("@/components/dashboard/ExplorerHUD"), { ssr: false });

export default function UniverseExplorerPage() {
  const { user, loading } = useRequireAuth();

  if (loading || !user) {
    return (
      <main className="relative w-full min-h-screen flex items-center justify-center" style={{ background: "#00000A" }}>
        <p className="font-display text-sm tracking-widest" style={{ color: "#00F0FF" }}>
          Initializing Explorer...
        </p>
      </main>
    );
  }

  return (
    <main className="relative w-full h-screen overflow-hidden" style={{ background: "#00000A" }}>
      {/* Back nav */}
      <Link
        href="/dashboard"
        className="absolute top-6 right-6 z-20 flex items-center gap-2 px-4 py-2 rounded-full font-display text-sm cursor-none"
        style={{
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.12)",
          color: "#00F0FF",
        }}
      >
        <FaArrowLeft size={12} /> Dashboard
      </Link>

      <div className="absolute top-6 left-6 z-20">
        <span className="font-mono text-xs uppercase tracking-[4px]" style={{ color: "rgba(0,240,255,0.6)" }}>
          Universe Explorer
        </span>
      </div>

      {/* Full screen 3D canvas */}
      <div className="absolute inset-0">
        <ExplorerEarth />
      </div>

      {/* HUD overlay */}
      <ExplorerHUD />
    </main>
  );
}
