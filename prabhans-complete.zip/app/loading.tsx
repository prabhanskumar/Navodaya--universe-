export default function Loading() {
  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50"
      style={{ background: "#00000A" }}
    >
      <div className="flex flex-col items-center gap-4">
        <div
          className="w-12 h-12 rounded-full border-2 border-t-transparent animate-spin"
          style={{ borderColor: "#00F0FF transparent #00F0FF #00F0FF" }}
        />
        <p className="font-display text-xs tracking-widest uppercase" style={{ color: "#00F0FF" }}>
          Loading Universe
        </p>
      </div>
    </div>
  );
}
